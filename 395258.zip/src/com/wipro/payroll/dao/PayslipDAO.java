package com.wipro.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.wipro.payroll.bean.PayslipBean;
import com.wipro.payroll.util.DBUtil;

public class PayslipDAO {
	Connection con=null;
	PreparedStatement pst=null;
	String result="";
	 ResultSet res=null;
	public String createPayslip(PayslipBean payslipBean) throws ClassNotFoundException
	{
	 con=DBUtil.getDBConnection();
	  String sql="insert into payslip_table values(?,?,?,?,?,?,?,?)";
	 try
	 {
	  pst=con.prepareStatement(sql);
	 pst.setString(1, payslipBean.getEmployeeId());
	 pst.setString(2, payslipBean.getMonth());
	 pst.setString(3, payslipBean.getYear());
	 pst.setDouble(4, payslipBean.getBasic());
	 pst.setDouble(5, payslipBean.getDa());
	 pst.setDouble(6,payslipBean.getHra());
	 pst.setDouble(7, payslipBean.getPf());
	 pst.setDouble(8, payslipBean.getNetSalary());
	 int i=pst.executeUpdate();
	 if(i>0)
	 {
		 result="SUCCESS"; 
	 }
	 else
	 {
		 result="FAILURE"; 
	 }
	 }catch(SQLException e)
	 {
		 result="FAILURE";
	 }		
		return result;
		
	}
	
	public boolean payslipExists(String empID,String month,String year) throws ClassNotFoundException
	{
		boolean flag=false;
		 con=DBUtil.getDBConnection();
		String sql="select *from payslip_table where empid=? and month=? and year=?";
		  try {
		 pst=con.prepareStatement(sql);
		  pst.setString(1, empID);
		  pst.setString(2, month);
		  pst.setString(3, year);
		 res=pst.executeQuery();
		if(res.next())
		 {
			flag=true;	 
		 }
		 else
		 {
			 flag=false;
		 }		
		}catch (SQLException e) 
		  {	
			  flag=false;
		  }		  
		return flag;
	}
}
