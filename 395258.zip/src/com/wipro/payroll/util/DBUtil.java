package com.wipro.payroll.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static Connection getDBConnection() throws ClassNotFoundException
	{
		Connection con=null;
		Class.forName("oracle.jdbc.driver.OracleDriver");	
		 try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","B63426395258","B63426395258");
	    System.out.println("Connected successfully");
		 } catch (SQLException e) {
		
		 System.out.println("not connected");
		}

		return con;
	}
}
