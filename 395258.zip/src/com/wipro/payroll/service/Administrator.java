package com.wipro.payroll.service;

import java.sql.Connection;

import com.wipro.payroll.bean.PayslipBean;
import com.wipro.payroll.dao.PayslipDAO;
import com.wipro.payroll.util.DBUtil;
import com.wipro.payroll.util.InvalidInputException;

public class Administrator {
	PayslipDAO dao=new PayslipDAO();
	Connection con=null;
	public String addPayslip(PayslipBean payslipBean) throws ClassNotFoundException
	{
		 con=DBUtil.getDBConnection();
		String result="";
		try
		{
		if(payslipBean==null || payslipBean.getEmployeeId()==null 
				|| payslipBean.getMonth()==null 
				|| payslipBean.getBasic()==0 || payslipBean.getYear()==null
				|| payslipBean.getDa()==0 || payslipBean.getHra()==0)
		{
			throw new InvalidInputException();
		}
		}catch(InvalidInputException e)
		{
			return e.toString();
		}		
	   boolean b=dao.payslipExists(payslipBean.getEmployeeId(),payslipBean.getMonth(), payslipBean.getYear());
	   if(b)
	   { 
			return "ALREADY EXISTS";
	   }
	    double val=computePF(payslipBean.getBasic());
		payslipBean.setPf(val);
		double sal=computeNetSalary(payslipBean.getBasic(),payslipBean.getHra(),payslipBean.getDa(),payslipBean.getPf());
		payslipBean.setNetSalary(sal);
		String str=dao.createPayslip(payslipBean);
		if(str.equals("SUCCESS"))
		{
			result=str+":"+payslipBean.getEmployeeId();
		}
		if(str.equals("FAILURE"))
		{
			result=str+":"+payslipBean.getEmployeeId();
		} 		   
		return result;
	}
	public double computeNetSalary(double basicPay,double HRA,double DA,double PF)
	{
		double netsal=basicPay+HRA+DA+PF;
		return netsal-5000;
	}
	public double computePF(double basicPay)
	{
		double pf=(10)*basicPay;
		return pf/100;
	}
	public static void main(String[] args) throws ClassNotFoundException {
		Administrator admin=new Administrator();
		PayslipBean payslipBean=new PayslipBean();
		payslipBean.setEmployeeId("JA1234");
		payslipBean.setMonth("FEB");
		payslipBean.setYear("2017");
		payslipBean.setBasic(35000);
		payslipBean.setDa(4500);
		payslipBean.setHra(10000);
		System.out.println(admin.addPayslip(payslipBean));
	}
}
